public class Server 
{
        
	public static void main(String[] args) 
	{
		chat_server myServer=new chat_server();
                	myServer.startRunning();
	}
}
